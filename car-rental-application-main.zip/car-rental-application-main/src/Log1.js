import React from "react";
import './Log1.css';
function Log1(){
    return(
        <div>
            <div class="login-box">
	<h2>Login</h2>
	<form action="">
		<div class="user-box">
			<input type="text" name="" required=""/>
			<label>Username</label>
		</div>
		<div class="user-box">
			<input type="password" name="" required=''/>
			<label for="">Password</label>
		</div>
		<a href="">
			<span></span>
			<span></span>
			<span></span>
			<span></span>
			Login
		</a>
	</form>
</div>
        </div>
    )
}
export default Log1