// import logo from './logo.svg';
import './App.css';
import Admin1 from './admincomponents/Admin1';
import Admin2 from './admincomponents/Admin2';
import Owners from './admincomponents/Owners';
import Status from './admincomponents/Status';
import ManageUsers from './admincomponents/ManageUsers';
import ManageOwners from './admincomponents/ManageOwners';
// import Admin from "./Components/Admin";
import { BrowserRouter, Routes ,Route} from 'react-router-dom';


function Adminapp() {
  return (
    <>
    {/* <Admin1 />
    <Admin2 /> */}
    <BrowserRouter>
    <Routes>
      <Route path='/' element={<Admin1/>}/>
      <Route path='/Admin1' element={<Admin1/>}/>
      <Route path='/Admin2' element={<Admin2/>}/> 
      <Route path='/Owners' element={<Owners/>}/>
      <Route path='/Status' element={<Status/>}/>
      <Route path='/ManageUsers' element={<ManageUsers/>}/>
      <Route path='/ManageOwners' element={<ManageOwners/>}/>
    </Routes>
    </BrowserRouter>
    </>
  );
}

export default Adminapp;
