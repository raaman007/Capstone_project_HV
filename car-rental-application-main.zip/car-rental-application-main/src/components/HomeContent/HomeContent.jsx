import React from 'react'

const HomeContent = () => {
  return (
    <div>
      
    </div>
  )
}

export default HomeContent
