import React from 'react'

function Car2() {
  return (
    <div>
      
    </div>
  )
}

export default Car2
