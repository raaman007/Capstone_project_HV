import React from 'react'
import car from '../images/thar1.webp';

const Car1 = () => {
  return (
 <>
    <div>
      <h1>Car1 Page</h1>
      <img src={car}/>
    </div>
 </>
  )
}

export default Car1;
